import React from 'react'
import Head from 'next/head'
import '../css/styles.css'
import { motion } from 'framer-motion'
import Link from 'next/link'

const local = "SAN ISIDRO / COMERCIAL";
const number = 10;

class myComponent extends React.Component {
    constructor(props) {
    super(props);
    this.state = {
      items : JSON,
      isLoaded : false
    };
  }
  componentDidMount() {
    try {
      setInterval(async () => {
        const number = await fetch('https://83gr8sv0l8.execute-api.us-east-1.amazonaws.com/test/grabar?ClienteID=Jorge&Local=jockey&Posicion=Puerta-MEDIO');
		console.log(number)
		const blocks = await res.json();
        const estado = blocks.estado;
        this.setState({
          items:estado,
          isLoaded: true
        })
      }, 10000);
    } catch(e){
      console.log(e)
    }
  }
  render() {
  var {isLoaded , items} = this.state;
  if (!isLoaded){
    return <div>Loading </div>;
  }
  return (
    <div className="App">
      <div>{items}</div>
    </div>
  );
  }
}

const index = () => {
	return (
		<React.Fragment>
			<Head>
				<title>web-aforo</title>
			</Head>
			<div className="container">
				<header>
					<div className="index">
						<motion.button whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
							<img src="/img/menu-icon-white.jpg" alt="" />
						</motion.button>
					</div>
				</header>
				<div className="contenido">
					<h1>AFORO</h1>
					<div className="info">
						<div className="img-container">
							<img src="/img/aforo-icono.png" alt="aforo-icono" />
						</div>
						<div className="number-value">
							<h1>{number}</h1>
							<h2> ACTUAL </h2>
						</div>
					</div>
					<div className="location">
						<h1>{local}</h1>
					</div>
				</div>
			</div>
		</React.Fragment>
	)
}

export default index